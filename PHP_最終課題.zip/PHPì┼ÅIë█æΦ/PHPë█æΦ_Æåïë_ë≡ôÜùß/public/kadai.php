<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        div{
            margin-bottom:50px;
            border: 1px solid #000000;
        }
    </style>
</head>
<body>
    <!-- //POSTされたデータを処理する。 -->
    <div>
        課題１：POSTデータの利用<br />
        <!-- 課題1:POSTされた kadai1 テキストボックスの内容を表示する。-->
        <?php
            if($_SERVER["REQUEST_METHOD"] == "POST"){
                //ここでテキストボックスの値を表示する
                echo($_POST['kadai1']);    
            }
        ?>
    
    </div>
    <div>
        課題２：数値計算<br />
        5&nbsp;+&nbsp;3&nbsp;=&nbsp;
        <!-- 課題2:POSTされた kadai2_1とkadai2_2 テキストボックスに入力された数値の合計を表示する。-->
        <?php
            if($_SERVER["REQUEST_METHOD"] == "POST"){
                //ここでテキストボックスの値を表示する
                echo($_POST['kadai2_1'] + $_POST['kadai2_2']);    
            }
        ?>
            
    </div>
    <div>
        課題３：セッションの利用<br />
        <!-- 課題3:セッションを利用し「課題のチェック」ボタンを押した回数を表示する。 -->
        <!-- 表示は「ボタンを押した回数：*回」と表示すること。 -->
        <!-- ボタンを押していない初期表示時(GET時)は何も表示しないこと。 -->
        <!-- 初回のみ、エラーが表示されるが、２回目以降が正常であれば問題ない。 -->
        <!-- 初回エラーも取り除きたい場合、未学習だがisset関数を利用することで、対象データが空であるかどうかの判定ができる。 -->
        <?php
            session_start();
            //$_SESSION = null;
            if($_SERVER["REQUEST_METHOD"] == "POST"){
                if(!isset($_SESSION["count"])){
                    $_SESSION["count"] = 0;
                }
                $count = $_SESSION["count"];
                $count ++;
                $_SESSION["count"] = $count;
                echo("ボタンを押した回数：".$count."回");
            }
        ?>
    </div>
    <div>
        課題４：高度な条件分岐<br />
        ここには何も表示しません。結果は課題３：の欄で確認します。
        <!-- 課題4:課題3の回数が10回を超え、11回になったら表示を1回にリセットする。 -->
        <!-- 注意点：セッションの中に入っているものは「文字列」であることに注意する。 -->
        <?php
            if($_SERVER["REQUEST_METHOD"] == "POST"){
                //プログラムは上から下に流れる。11回と表示されてしまった後では遅い。
                //従って、10回と表示した時に、内部的に0に戻してやることで次回が1になる。
                $count = $_SESSION["count"];
                //sessionは文字なので、数値に変換するか、文字として比較する。
                if($count == "10"){
                    $_SESSION["count"] = 0;
                }
            }
        ?>
    </div>
    <div>
        <?php
            //ここは編集しないこと
            $messages = ["晴れ","雨","曇り"];
        ?>
        課題５：配列の利用<br />
        <!-- 上記$messagesを利用し、今日は晴れです、今日は雨です、今日は曇りです、をランダムに表示する。 -->
        <?php
            if($_SERVER["REQUEST_METHOD"] == "POST"){
                $message = $messages[rand(0,2)];
                echo("今日は".$message."です。");
            }
        ?>
    </div>




    <!-- 以下はデータをPOSTするためのフォームです。 -->
    <!-- ここから下は編集してはいけません。 -->
    <div>
        <form action="./kadai.php" method="post">
            課題１用のデータ：<input type="text" name="kadai1" value="これが表示されればＯＫです"><br />
            課題２用のデータ：<input type="text" name="kadai2_1" value="5"><input type="text" name="kadai2_2" value="3"><br />
            <input type="submit" value="課題のチェック">
            <a href="./kadai.php">リセット</a>
        </form>
    </div>
    
</body>
</html>