<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Todoリスト</title>
</head>
<body>
    <h1>Todo一覧</h1>
    <div>
        <div style="color:red;">
            @if ($errors->any())
                @foreach ($errors->all() as $error)
                    {{ $error }}<br />
                @endforeach
            @endif
            @if (session('flash_message'))
                {{ session('flash_message') }}
            @endif
        </div>
        Todoを追加<br />
        <form action="./" method="post">
            <input type="hidden" name="action" value="add" />
            <input type="hidden" name="status" value="0" />
            <input type="text" name="title" /><br />
            <button >追加</button>
        </form>
        <table border="1">
            <thead>
                <tr>
                    <th>状態</th>
                    <th>やること</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                @foreach($todos as $todo)
                    <tr>
                        <td>
                            @if ($todo->status == 0)
                                <span>未完了</span>
                            @else
                                <span>完了</span>
                            @endif
                        </td>
                        <td>{{$todo->title}}</td>
                        <td>
                            <form action="./" method="post">
                                <input type="hidden" name="action" value="complete" />
                                <input type="hidden" name="id" value="{{$todo->id}}" />
                                <input type="submit" value="完了にする" />
                            </form>
                        </td>
                    </tr>
                @endforeach    
            </tbody>
        </table>
    </div>
</body>
</html>

