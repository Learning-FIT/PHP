<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Todo;

class IndexController extends Controller
{
    public function index(){
        $todos = Todo::all()->sortBy('status');
        return view('index',compact('todos'));
    }

    public function post(Request $request){
        if($request->input('action') == 'add'){
            //追加ボタンの処理
            $request->validate([
                'title' => ['required']
            ],[
                'title.required' => 'Todoのタイトルを入力してください。'
            ]);
            $todo = new Todo();
            $todo->fill($request->input());
            $todo->save();
            return redirect('./')
                ->with('flash_message', 'Todoを追加しました。');
        }elseif($request->input('action') == 'complete'){
            //完了ボタンの処理
            $todo = Todo::find($request->input('id'));
            $todo->status = 1;
            $todo->save();
            return redirect('./');
        }
        //actionはaddとcompleteだけなため、これより下は発生しない。
    }

}
